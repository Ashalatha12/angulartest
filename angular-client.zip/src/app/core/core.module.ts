import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CoreRoutingModule } from './core-routing.module';
import { FooterComponent } from './components/footer/footer.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { LandingComponent } from './components/landing/landing.component';
import { httpInterceptorProviders } from './interceptors';

@NgModule({
  declarations: [FooterComponent, NavbarComponent, LandingComponent],
  imports: [CommonModule, CoreRoutingModule],
  providers: [httpInterceptorProviders],
  exports: [NavbarComponent, LandingComponent, FooterComponent],
})
export class CoreModule {}
