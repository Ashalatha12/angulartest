import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class HeaderInterceptor implements HttpInterceptor {
  constructor() {}

  intercept(
    request: HttpRequest<unknown>,
    next: HttpHandler
  ): Observable<HttpEvent<unknown>> {
    if (localStorage.getItem('token') == null) {
      return next.handle(request);
    }
    request = request.clone({
      setHeaders: {
        'x-auth-token': localStorage.getItem('token'),
      },
    });
    console.log(JSON.stringify(request));
    return next.handle(request);

    return next.handle(request);
  }
}
