import { Profiles } from './profiles';

describe('Profiles', () => {
  it('should create an instance', () => {
    expect(new Profiles()).toBeTruthy();
  });
});
