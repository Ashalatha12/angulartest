import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DasboardComponent } from './components/dasboard/dasboard.component';
import { httpInterceptorProviders } from '../core/interceptors';
import { AuthService } from '../auth/services/auth.service';
import { CreateProfileService } from '../create-profile/services/create-profile.service';
import { HttpClientModule } from '@angular/common/http';
import { CoreModule } from '../core/core.module';

@NgModule({
  declarations: [DasboardComponent],
  providers: [httpInterceptorProviders, AuthService, CreateProfileService],
  imports: [CommonModule, DashboardRoutingModule, HttpClientModule, CoreModule],
})
export class DashboardModule {}
